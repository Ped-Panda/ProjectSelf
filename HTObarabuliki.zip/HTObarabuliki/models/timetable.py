import sqlalchemy
from database.db_session import SqlAlchemyBase


class TimeTable(SqlAlchemyBase):
    __tablename__ = 'timetable'

    id = sqlalchemy.Column(sqlalchemy.Integer, primary_key=True, autoincrement=True)
    name = sqlalchemy.Column(sqlalchemy.String, nullable=False)

    crew = sqlalchemy.orm.relationship("Crew", back_populates='timetable')