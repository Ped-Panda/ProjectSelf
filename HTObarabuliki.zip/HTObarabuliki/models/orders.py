import sqlalchemy
from database.db_session import SqlAlchemyBase


class Orders(SqlAlchemyBase):
    __tablename__ = 'orders'

    id = sqlalchemy.Column(sqlalchemy.String, primary_key=True)
    start_date = sqlalchemy.Column(sqlalchemy.DateTime, nullable=False)
    end_date = sqlalchemy.Column(sqlalchemy.DateTime, nullable=False)
    customer_id = sqlalchemy.Column(
        sqlalchemy.String, sqlalchemy.ForeignKey('customers.id'))
    production_id = sqlalchemy.Column(
        sqlalchemy.Integer, sqlalchemy.ForeignKey('production_types.id'))
    count = sqlalchemy.Column(sqlalchemy.Integer, nullable=True)
    info = sqlalchemy.Column(sqlalchemy.String, nullable=True)
    status_id = sqlalchemy.Column(
        sqlalchemy.Integer, sqlalchemy.ForeignKey('order_status_types.id'))

    prod_order = sqlalchemy.orm.relationship("ProdOrders", back_populates='order')

    customer = sqlalchemy.orm.relationship("Customers")
    production = sqlalchemy.orm.relationship("ProductionTypes")
    status = sqlalchemy.orm.relationship("OrderStatusTypes")

