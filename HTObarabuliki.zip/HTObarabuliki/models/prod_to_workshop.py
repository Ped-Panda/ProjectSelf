import sqlalchemy
from database.db_session import SqlAlchemyBase


class ProdToWorkshop(SqlAlchemyBase):
    __tablename__ = 'prod_to_workshop'

    id = sqlalchemy.Column(sqlalchemy.Integer, primary_key=True)
    production_id = sqlalchemy.Column(sqlalchemy.Integer, sqlalchemy.ForeignKey('production_types.id'))

    workshop_id = sqlalchemy.Column(sqlalchemy.Integer, sqlalchemy.ForeignKey('workshops.id'))

    production = sqlalchemy.orm.relationship("ProductionTypes")
    workshop = sqlalchemy.orm.relationship("Workshops")
