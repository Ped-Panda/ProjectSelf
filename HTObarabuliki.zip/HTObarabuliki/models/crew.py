import sqlalchemy
from database.db_session import SqlAlchemyBase


class Crew(SqlAlchemyBase):
    __tablename__ = 'crew'

    id = sqlalchemy.Column(sqlalchemy.String, primary_key=True)
    type_id = sqlalchemy.Column(sqlalchemy.Integer, sqlalchemy.ForeignKey("crew_type.id"))
    area_id = sqlalchemy.Column(sqlalchemy.Integer, sqlalchemy.ForeignKey("areas.id"))
    start_date = sqlalchemy.Column(sqlalchemy.DateTime, nullable=False)
    timetable_id = sqlalchemy.Column(sqlalchemy.Integer, sqlalchemy.ForeignKey("timetable.id"))
    employees = sqlalchemy.Column(sqlalchemy.String, nullable=True)
    schedule = sqlalchemy.Column(sqlalchemy.String, nullable=True)

    crew_type = sqlalchemy.orm.relationship("CrewType")
    areas = sqlalchemy.orm.relationship("Areas")
    timetable = sqlalchemy.orm.relationship("TimeTable")

    note_crew_employee = sqlalchemy.orm.relationship("NoteCrewEmployee", back_populates='crew')