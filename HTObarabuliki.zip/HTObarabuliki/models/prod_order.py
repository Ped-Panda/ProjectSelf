import sqlalchemy
from database.db_session import SqlAlchemyBase


class ProdOrders(SqlAlchemyBase):
    __tablename__ = 'prod_orders'

    id = sqlalchemy.Column(sqlalchemy.String, primary_key=True)
    start_date = sqlalchemy.Column(sqlalchemy.DateTime, nullable=False)
    end_date = sqlalchemy.Column(sqlalchemy.DateTime, nullable=False)
    order_id = sqlalchemy.Column(
        sqlalchemy.String, sqlalchemy.ForeignKey('orders.id'))
    production_id = sqlalchemy.Column(
        sqlalchemy.Integer, sqlalchemy.ForeignKey('production_types.id'))
    workshops = sqlalchemy.Column(sqlalchemy.String, nullable=False)
    count = sqlalchemy.Column(sqlalchemy.String, nullable=True)
    info = sqlalchemy.Column(sqlalchemy.String, nullable=True)

    order = sqlalchemy.orm.relationship("Orders")
    production = sqlalchemy.orm.relationship("ProductionTypes")

    area_order = sqlalchemy.orm.relationship("AreaOrders", back_populates='order')
    workshop_shift = sqlalchemy.orm.relationship("WorkingShift", back_populates='order')

