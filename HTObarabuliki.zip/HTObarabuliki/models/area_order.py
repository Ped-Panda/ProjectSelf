import sqlalchemy
from database.db_session import SqlAlchemyBase


class AreaOrders(SqlAlchemyBase):
    __tablename__ = 'area_orders'

    id = sqlalchemy.Column(sqlalchemy.String, primary_key=True)
    start_date = sqlalchemy.Column(sqlalchemy.DateTime, nullable=False)
    end_date = sqlalchemy.Column(sqlalchemy.DateTime, nullable=False)
    order_id = sqlalchemy.Column(sqlalchemy.String, sqlalchemy.ForeignKey('prod_orders.id'))
    area_name = sqlalchemy.Column(sqlalchemy.Integer, sqlalchemy.ForeignKey('areas.id'))
    info = sqlalchemy.Column(sqlalchemy.String, nullable=True)
    status = sqlalchemy.Column(sqlalchemy.Integer, nullable=False, default=1)

    order = sqlalchemy.orm.relationship("ProdOrders")
    area = sqlalchemy.orm.relationship("Areas")

