import sqlalchemy
from database.db_session import SqlAlchemyBase
from werkzeug.security import generate_password_hash, check_password_hash


class Staff(SqlAlchemyBase):
    __tablename__ = 'staff'

    id = sqlalchemy.Column(sqlalchemy.String, primary_key=True)
    name = sqlalchemy.Column(sqlalchemy.String, nullable=False)
    surname = sqlalchemy.Column(sqlalchemy.String, nullable=False)
    login = sqlalchemy.Column(sqlalchemy.String, index=True, unique=True, nullable=False)
    password = sqlalchemy.Column(sqlalchemy.String, nullable=False)
    credential = sqlalchemy.Column(
        sqlalchemy.Integer, sqlalchemy.ForeignKey("credential_types.id"))

    credential_type = sqlalchemy.orm.relationship("CredentialTypes")

    def set_password(self, password):
        self.hashed_password = generate_password_hash(password)

    def check_password(self, password):
        return check_password_hash(self.hashed_password, password)
