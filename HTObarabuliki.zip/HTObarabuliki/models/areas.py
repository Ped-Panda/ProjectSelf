import sqlalchemy
from database.db_session import SqlAlchemyBase


class Areas(SqlAlchemyBase):
    __tablename__ = 'areas'

    id = sqlalchemy.Column(sqlalchemy.Integer, primary_key=True, autoincrement=True)
    workshop_id = sqlalchemy.Column(sqlalchemy.Integer, sqlalchemy.ForeignKey('workshops.id'))
    name = sqlalchemy.Column(sqlalchemy.String, nullable=False)
    info = sqlalchemy.Column(sqlalchemy.String, nullable=True)
    limit = sqlalchemy.Column(sqlalchemy.Integer, nullable=False)

    workshop = sqlalchemy.orm.relationship("Workshops")
    area_order = sqlalchemy.orm.relationship("AreaOrders", back_populates='area')
    workshop_shift = sqlalchemy.orm.relationship("WorkingShift", back_populates='area')
    crew = sqlalchemy.orm.relationship("Crew", back_populates='areas')