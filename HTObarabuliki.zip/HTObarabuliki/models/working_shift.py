import sqlalchemy
from database.db_session import SqlAlchemyBase


class WorkingShift(SqlAlchemyBase):
    __tablename__ = 'working_shift'

    id = sqlalchemy.Column(sqlalchemy.String, primary_key=True)
    create_date = sqlalchemy.Column(sqlalchemy.DateTime, nullable=False)
    prod_type_id = sqlalchemy.Column(sqlalchemy.String, sqlalchemy.ForeignKey('production_types.id'))
    order_id = sqlalchemy.Column(sqlalchemy.String, sqlalchemy.ForeignKey('prod_orders.id'))
    area_name = sqlalchemy.Column(sqlalchemy.Integer, sqlalchemy.ForeignKey('areas.id'))
    shift_date = sqlalchemy.Column(sqlalchemy.DateTime, nullable=False)
    info = sqlalchemy.Column(sqlalchemy.String, nullable=True)
    count = sqlalchemy.Column(sqlalchemy.Integer, nullable=False)

    order = sqlalchemy.orm.relationship("ProdOrders")
    area = sqlalchemy.orm.relationship("Areas")
    prod_type = sqlalchemy.orm.relationship("ProductionTypes")

