import sqlalchemy
from database.db_session import SqlAlchemyBase


class ProductionTypes(SqlAlchemyBase):
    __tablename__ = 'production_types'

    id = sqlalchemy.Column(sqlalchemy.Integer, primary_key=True, autoincrement=True)
    name = sqlalchemy.Column(sqlalchemy.String, nullable=False)

    order = sqlalchemy.orm.relationship("Orders", back_populates='production')
    prod_to_workshop = sqlalchemy.orm.relationship("ProdToWorkshop", back_populates='production')
    prod_order = sqlalchemy.orm.relationship("ProdOrders", back_populates='production')
    workshop_shift = sqlalchemy.orm.relationship("WorkingShift", back_populates='prod_type')

    def __repr__(self):
        return f'<prod> {self.id} {self.name}'