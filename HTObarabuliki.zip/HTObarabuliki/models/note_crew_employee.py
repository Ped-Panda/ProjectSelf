import sqlalchemy
from database.db_session import SqlAlchemyBase


class NoteCrewEmployee(SqlAlchemyBase):
    __tablename__ = 'note_crew_employee'

    id = sqlalchemy.Column(sqlalchemy.Integer, primary_key=True, autoincrement=True)
    employee_id = sqlalchemy.Column(sqlalchemy.String, sqlalchemy.ForeignKey("employee.id"))
    crew_id = sqlalchemy.Column(sqlalchemy.String, sqlalchemy.ForeignKey("crew.id"))

    employee = sqlalchemy.orm.relationship("Employee")
    crew = sqlalchemy.orm.relationship("Crew")