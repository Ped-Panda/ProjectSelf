import sqlalchemy
from database.db_session import SqlAlchemyBase


class Workshops(SqlAlchemyBase):
    __tablename__ = 'workshops'

    id = sqlalchemy.Column(sqlalchemy.Integer, primary_key=True, autoincrement=True)
    name = sqlalchemy.Column(sqlalchemy.String, nullable=False)

    areas = sqlalchemy.orm.relationship("Areas", back_populates='workshop')
    prod_to_workshop = sqlalchemy.orm.relationship("ProdToWorkshop", back_populates='workshop')
    employee = sqlalchemy.orm.relationship("Employee", back_populates='workshop')