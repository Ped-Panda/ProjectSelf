import sqlalchemy
from database.db_session import SqlAlchemyBase


class CredentialTypes(SqlAlchemyBase):
    __tablename__ = 'credential_types'

    id = sqlalchemy.Column(sqlalchemy.Integer, primary_key=True, autoincrement=True)
    name = sqlalchemy.Column(sqlalchemy.String, nullable=False)

    staff = sqlalchemy.orm.relationship("Staff", back_populates='credential_type')