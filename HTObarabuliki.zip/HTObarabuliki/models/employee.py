import sqlalchemy
from database.db_session import SqlAlchemyBase


class Employee(SqlAlchemyBase):
    __tablename__ = 'employee'

    id = sqlalchemy.Column(sqlalchemy.String, primary_key=True)
    name = sqlalchemy.Column(sqlalchemy.String, nullable=False)
    is_master = sqlalchemy.Column(sqlalchemy.Boolean, nullable=False, default=False)
    workshop_id = sqlalchemy.Column(
        sqlalchemy.Integer, sqlalchemy.ForeignKey("workshops.id"))

    workshop = sqlalchemy.orm.relationship("Workshops")

    note_crew_employee = sqlalchemy.orm.relationship("NoteCrewEmployee", back_populates='employee')




