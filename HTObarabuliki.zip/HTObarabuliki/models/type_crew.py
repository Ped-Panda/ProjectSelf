import sqlalchemy
from database.db_session import SqlAlchemyBase


class CrewType(SqlAlchemyBase):
    __tablename__ = 'crew_type'

    id = sqlalchemy.Column(sqlalchemy.Integer, primary_key=True, autoincrement=True)
    name = sqlalchemy.Column(sqlalchemy.String, nullable=False)

    crew = sqlalchemy.orm.relationship("Crew", back_populates='crew_type')