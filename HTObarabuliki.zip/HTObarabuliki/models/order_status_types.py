import sqlalchemy
from database.db_session import SqlAlchemyBase


class OrderStatusTypes(SqlAlchemyBase):
    __tablename__ = 'order_status_types'

    id = sqlalchemy.Column(sqlalchemy.Integer, primary_key=True, autoincrement=True)
    name = sqlalchemy.Column(sqlalchemy.String, nullable=False)

    order = sqlalchemy.orm.relationship("Orders", back_populates='status')