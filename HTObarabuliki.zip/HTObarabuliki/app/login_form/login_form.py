from PyQt5.QtWidgets import QMainWindow
from app.commercial_service.commercial_main_window import CommercialMainForm
from app.production_service.prodaction_main_window import ProductionMainForm
from app.technologist_service.technologist_main_window import TechnologistMainForm
from app.employee_service.employee_main_window import EmployeeMainForm
from database import db_session
from models.staff import Staff
from sqlalchemy import and_
from UI.new_login_ui import Ui_MainWindow


class LoginForm(QMainWindow, Ui_MainWindow):
    def __init__(self, screen):
        super().__init__()
        self.width = screen.size().width()
        self.height = screen.size().height()
        self.setupUi(self)
        self.btn.clicked.connect(self.open_second_form)
        self.setFixedSize(self.width, self.height)
        self.setGeometry(0, 0, self.width, self.height)

    def open_second_form(self):
        db_sess = db_session.create_session()
        user = db_sess.query(Staff).where(and_(
            Staff.login == self.login_input.text(),
            Staff.password == self.password_input.text()
            )
        ).first()
        if user:
            if user.credential == 1:
                self.second_form = CommercialMainForm(self, self.width, self.height)
            elif user.credential == 2:
                self.second_form = ProductionMainForm(self, self.width, self.height)
            elif user.credential == 3:
                self.second_form = TechnologistMainForm(self, self.width, self.height)
            elif user.credential == 4:
                self.second_form = EmployeeMainForm(self, self.width, self.height)
            self.second_form.show()
            self.close()
        else:
            self.error_lbl.setText("Неверный логин или пароль")